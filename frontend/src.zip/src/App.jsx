import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import MenuPage from "./pages/MenuPage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import AdminMenuPage from "./pages/AdminMenuPage";
import PredictionPage from "./pages/PredictionPage";

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-slate-50">
        <nav className="bg-white shadow px-6 py-4 flex gap-4">
          <Link to="/" className="font-semibold text-blue-700">
            Kantin Lama IT Del
          </Link>
          <Link to="/admin/orders" className="text-gray-700">
            Admin Orders
          </Link>
          <Link to="/admin/menus" className="text-gray-700">
            Admin Menu
          </Link>
          <Link to="/admin/prediction" className="text-gray-700">
            Prediction
          </Link>
        </nav>

        <Routes>
          <Route path="/" element={<MenuPage />} />
          <Route path="/admin/orders" element={<AdminDashboardPage />} />
          <Route path="/admin/menus" element={<AdminMenuPage />} />
          <Route path="/admin/prediction" element={<PredictionPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
