import { useEffect, useState } from "react";
import api from "../api/api";

export default function AdminDashboardPage() {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await api.get("/orders/");
    setOrders(res.data);
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const updateStatus = async (orderId, status) => {
    await api.patch(`/orders/${orderId}/status`, { status });
    fetchOrders();
  };

  const statusClass = {
    waiting: "bg-gray-100 text-gray-700",
    processing: "bg-yellow-100 text-yellow-700",
    ready: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">
        Dashboard Pesanan
      </h1>

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="bg-white rounded-2xl shadow p-5">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-blue-700">
                  {order.queue_number}
                </h2>
                <p className="text-slate-700">
                  Pelanggan: {order.customer_name}
                </p>
                <p className="text-slate-700">
                  Total: Rp {order.total_price.toLocaleString("id-ID")}
                </p>
                <span
                  className={`inline-block mt-2 px-3 py-1 rounded-full text-sm ${statusClass[order.status]}`}
                >
                  {order.status}
                </span>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => updateStatus(order.id, "processing")}
                  className="bg-yellow-500 text-white px-3 py-2 rounded-xl"
                >
                  Proses
                </button>
                <button
                  onClick={() => updateStatus(order.id, "ready")}
                  className="bg-blue-600 text-white px-3 py-2 rounded-xl"
                >
                  Siap
                </button>
                <button
                  onClick={() => updateStatus(order.id, "completed")}
                  className="bg-green-600 text-white px-3 py-2 rounded-xl"
                >
                  Selesai
                </button>
                <button
                  onClick={() => updateStatus(order.id, "cancelled")}
                  className="bg-red-600 text-white px-3 py-2 rounded-xl"
                >
                  Batal
                </button>
              </div>
            </div>
          </div>
        ))}

        {orders.length === 0 && (
          <div className="bg-white rounded-2xl shadow p-5 text-slate-500">
            Belum ada pesanan.
          </div>
        )}
      </div>
    </div>
  );
}
