import { useEffect, useState } from "react";
import api from "../api/api";

export default function MenuPage() {
  const [menus, setMenus] = useState([]);
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");

  const fetchMenus = async () => {
    const res = await api.get("/menus/");
    setMenus(res.data);
  };

  useEffect(() => {
    fetchMenus();
  }, []);

  const addToCart = (menu) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.menu_item_id === menu.id);

      if (existing) {
        return prev.map((item) =>
          item.menu_item_id === menu.id
            ? { ...item, quantity: item.quantity + 1 }
            : item,
        );
      }

      return [
        ...prev,
        {
          menu_item_id: menu.id,
          name: menu.name,
          price: menu.price,
          quantity: 1,
        },
      ];
    });
  };

  const checkout = async () => {
    if (!customerName.trim()) {
      alert("Nama pelanggan wajib diisi");
      return;
    }

    if (cart.length === 0) {
      alert("Keranjang masih kosong");
      return;
    }

    const idempotencyKey = crypto.randomUUID();

    const payload = {
      customer_name: customerName,
      items: cart.map((item) => ({
        menu_item_id: item.menu_item_id,
        quantity: item.quantity,
      })),
    };

    try {
      const res = await api.post("/orders/checkout", payload, {
        headers: {
          "Idempotency-Key": idempotencyKey,
        },
      });

      alert(`Pesanan berhasil. Nomor antrian: ${res.data.queue_number}`);
      setCart([]);
      fetchMenus();
    } catch (error) {
      alert(error.response?.data?.detail || "Checkout gagal");
    }
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="p-6">
      <section className="mb-6">
        <h1 className="text-3xl font-bold text-slate-800">
          Kantin Lama IT Del
        </h1>
        <p className="text-slate-500">
          Sistem pemesanan dan antrian cerdas berbasis web.
        </p>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
          {menus.map((menu) => (
            <div key={menu.id} className="bg-white rounded-2xl shadow p-5">
              <h2 className="font-bold text-lg text-slate-800">{menu.name}</h2>
              <p className="text-sm text-slate-500 mt-1">
                {menu.description || "Tidak ada deskripsi"}
              </p>

              <div className="mt-4 flex justify-between">
                <p className="font-bold text-blue-700">
                  Rp {menu.price.toLocaleString("id-ID")}
                </p>
                <p className="text-sm text-slate-600">Stok: {menu.stock}</p>
              </div>

              <button
                onClick={() => addToCart(menu)}
                disabled={menu.stock <= 0 || !menu.is_available}
                className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-xl disabled:bg-gray-400"
              >
                {menu.stock > 0 && menu.is_available
                  ? "Tambah ke Keranjang"
                  : "Stok Habis"}
              </button>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow p-5 h-fit">
          <h2 className="font-bold text-xl mb-4">Keranjang</h2>

          <input
            type="text"
            placeholder="Nama pelanggan"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            className="w-full border rounded-xl px-3 py-2 mb-4"
          />

          {cart.length === 0 ? (
            <p className="text-slate-500">Belum ada pesanan.</p>
          ) : (
            <div className="space-y-2">
              {cart.map((item) => (
                <div
                  key={item.menu_item_id}
                  className="flex justify-between text-sm"
                >
                  <span>
                    {item.name} x {item.quantity}
                  </span>
                  <span>
                    Rp {(item.price * item.quantity).toLocaleString("id-ID")}
                  </span>
                </div>
              ))}

              <div className="border-t pt-3 mt-3 flex justify-between font-bold">
                <span>Total</span>
                <span>Rp {total.toLocaleString("id-ID")}</span>
              </div>

              <button
                onClick={checkout}
                className="w-full mt-4 bg-green-600 hover:bg-green-700 text-white py-2 rounded-xl"
              >
                Checkout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
