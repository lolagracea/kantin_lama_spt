import { useEffect, useState } from "react";
import api from "../api/api";

export default function AdminMenuPage() {
  const [menus, setMenus] = useState([]);
  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    stock: "",
  });

  const fetchMenus = async () => {
    const res = await api.get("/menus/");
    setMenus(res.data);
  };

  useEffect(() => {
    fetchMenus();
  }, []);

  const createMenu = async (e) => {
    e.preventDefault();

    await api.post("/menus/", {
      name: form.name,
      description: form.description,
      price: Number(form.price),
      stock: Number(form.stock),
    });

    setForm({
      name: "",
      description: "",
      price: "",
      stock: "",
    });

    fetchMenus();
  };

  const deleteMenu = async (id) => {
    if (!confirm("Yakin hapus menu ini?")) return;

    await api.delete(`/menus/${id}`);
    fetchMenus();
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">
        Kelola Menu Kantin
      </h1>

      <form
        onSubmit={createMenu}
        className="bg-white rounded-2xl shadow p-5 mb-6 grid grid-cols-1 md:grid-cols-4 gap-3"
      >
        <input
          placeholder="Nama menu"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="border rounded-xl px-3 py-2"
          required
        />

        <input
          placeholder="Deskripsi"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })}
          className="border rounded-xl px-3 py-2"
        />

        <input
          type="number"
          placeholder="Harga"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })}
          className="border rounded-xl px-3 py-2"
          required
        />

        <input
          type="number"
          placeholder="Stok"
          value={form.stock}
          onChange={(e) => setForm({ ...form, stock: e.target.value })}
          className="border rounded-xl px-3 py-2"
          required
        />

        <button className="md:col-span-4 bg-blue-600 text-white py-2 rounded-xl">
          Tambah Menu
        </button>
      </form>

      <div className="bg-white rounded-2xl shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-100">
            <tr>
              <th className="text-left p-3">Menu</th>
              <th className="text-left p-3">Harga</th>
              <th className="text-left p-3">Stok</th>
              <th className="text-left p-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {menus.map((menu) => (
              <tr key={menu.id} className="border-t">
                <td className="p-3">{menu.name}</td>
                <td className="p-3">Rp {menu.price.toLocaleString("id-ID")}</td>
                <td className="p-3">{menu.stock}</td>
                <td className="p-3">
                  <button
                    onClick={() => deleteMenu(menu.id)}
                    className="bg-red-600 text-white px-3 py-1 rounded-lg"
                  >
                    Hapus
                  </button>
                </td>
              </tr>
            ))}

            {menus.length === 0 && (
              <tr>
                <td className="p-3 text-slate-500" colSpan="4">
                  Belum ada menu.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
