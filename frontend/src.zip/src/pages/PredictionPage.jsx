import { useState } from "react";
import api from "../api/api";

export default function PredictionPage() {
  const [form, setForm] = useState({
    day_of_week: 1,
    hour: 12,
    menu_id: 1,
    stock_start: 50,
  });

  const [result, setResult] = useState(null);

  const predict = async (e) => {
    e.preventDefault();

    try {
      const res = await api.post("/predictions/demand", {
        day_of_week: Number(form.day_of_week),
        hour: Number(form.hour),
        menu_id: Number(form.menu_id),
        stock_start: Number(form.stock_start),
      });

      setResult(res.data.result);
    } catch (error) {
      alert(error.response?.data?.detail || "Prediksi gagal");
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-slate-800 mb-6">
        GPU-Based Demand Prediction
      </h1>

      <form
        onSubmit={predict}
        className="bg-white rounded-2xl shadow p-5 grid grid-cols-1 md:grid-cols-4 gap-3 mb-6"
      >
        <input
          type="number"
          placeholder="Hari 1-7"
          value={form.day_of_week}
          onChange={(e) => setForm({ ...form, day_of_week: e.target.value })}
          className="border rounded-xl px-3 py-2"
        />

        <input
          type="number"
          placeholder="Jam"
          value={form.hour}
          onChange={(e) => setForm({ ...form, hour: e.target.value })}
          className="border rounded-xl px-3 py-2"
        />

        <input
          type="number"
          placeholder="Menu ID"
          value={form.menu_id}
          onChange={(e) => setForm({ ...form, menu_id: e.target.value })}
          className="border rounded-xl px-3 py-2"
        />

        <input
          type="number"
          placeholder="Stok awal"
          value={form.stock_start}
          onChange={(e) => setForm({ ...form, stock_start: e.target.value })}
          className="border rounded-xl px-3 py-2"
        />

        <button className="md:col-span-4 bg-blue-600 text-white py-2 rounded-xl">
          Prediksi Demand
        </button>
      </form>

      {result && (
        <div className="bg-white rounded-2xl shadow p-5">
          <h2 className="font-bold text-xl mb-3">Hasil Prediksi</h2>
          <p>
            Prediksi permintaan: <b>{result.predicted_demand}</b> porsi
          </p>
          <p>
            Rekomendasi stok: <b>{result.recommended_stock}</b> porsi
          </p>
        </div>
      )}
    </div>
  );
}
