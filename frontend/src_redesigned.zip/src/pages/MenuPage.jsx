import { useEffect, useState } from "react";
import api from "../api/api";

export default function MenuPage() {
  const [menus, setMenus] = useState([]);
  const [cart, setCart] = useState([]);
  const [customerName, setCustomerName] = useState("");

  const fetchMenus = async () => {
    const res = await api.get("/menus/");
    setMenus(res.data);
  };

  useEffect(() => {
    fetchMenus();
  }, []);

  const addToCart = (menu) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.menu_item_id === menu.id);
      if (existing) {
        return prev.map((item) =>
          item.menu_item_id === menu.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { menu_item_id: menu.id, name: menu.name, price: menu.price, quantity: 1 }];
    });
  };

  const removeFromCart = (menuItemId) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.menu_item_id === menuItemId);
      if (existing && existing.quantity > 1) {
        return prev.map((item) =>
          item.menu_item_id === menuItemId ? { ...item, quantity: item.quantity - 1 } : item
        );
      }
      return prev.filter((item) => item.menu_item_id !== menuItemId);
    });
  };

  const checkout = async () => {
    if (!customerName.trim()) { alert("Nama pelanggan wajib diisi"); return; }
    if (cart.length === 0) { alert("Keranjang masih kosong"); return; }

    const idempotencyKey = crypto.randomUUID();
    const payload = {
      customer_name: customerName,
      items: cart.map((item) => ({ menu_item_id: item.menu_item_id, quantity: item.quantity })),
    };

    try {
      const res = await api.post("/orders/checkout", payload, {
        headers: { "Idempotency-Key": idempotencyKey },
      });
      alert(`Pesanan berhasil! Nomor antrian: ${res.data.queue_number}`);
      setCart([]);
      setCustomerName("");
      fetchMenus();
    } catch (error) {
      alert(error.response?.data?.detail || "Checkout gagal");
    }
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1.5rem' }}>
      {/* Hero Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #8B0D1E 0%, #C0152A 50%, #A01020 100%)',
        borderRadius: '20px',
        padding: '2.5rem 3rem',
        marginBottom: '2.5rem',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: '0 12px 40px rgba(192, 21, 42, 0.35)',
      }}>
        {/* Decorative circles */}
        <div style={{ position: 'absolute', top: '-40px', right: '-40px', width: '160px', height: '160px', borderRadius: '50%', background: 'rgba(212,160,23,0.15)' }} />
        <div style={{ position: 'absolute', bottom: '-60px', right: '80px', width: '200px', height: '200px', borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }} />

        <div style={{ position: 'relative' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '0.75rem' }}>
            <div style={{ width: '40px', height: '3px', background: '#D4A017', borderRadius: '2px' }} />
            <span style={{ color: '#D4A017', fontSize: '0.8rem', fontWeight: '600', letterSpacing: '0.15em', textTransform: 'uppercase' }}>
              Selamat Datang
            </span>
          </div>
          <h1 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: 'clamp(1.8rem, 4vw, 3rem)',
            fontWeight: '900',
            color: '#FFFFFF',
            margin: '0 0 0.75rem',
            lineHeight: 1.1,
          }}>
            Kantin Lama<br />
            <span style={{ color: '#F5C842' }}>IT Del</span>
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '1rem', margin: 0, maxWidth: '400px' }}>
            Sistem pemesanan dan antrian cerdas berbasis web.
          </p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '2rem', alignItems: 'start' }}>
        {/* Menu Grid */}
        <div>
          <h2 style={{
            fontFamily: "'Playfair Display', serif",
            fontSize: '1.5rem',
            fontWeight: '700',
            color: '#8B0D1E',
            marginBottom: '1.25rem',
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
          }}>
            <span>🍛</span> Pilihan Menu
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1.25rem' }}>
            {menus.map((menu, i) => {
              const inCart = cart.find((c) => c.menu_item_id === menu.id);
              const available = menu.stock > 0 && menu.is_available;
              return (
                <div
                  key={menu.id}
                  style={{
                    background: '#FFFFFF',
                    borderRadius: '16px',
                    padding: '1.5rem',
                    boxShadow: '0 4px 20px rgba(139,13,30,0.08)',
                    border: inCart ? '2px solid #C0152A' : '2px solid transparent',
                    transition: 'all 0.25s ease',
                    animation: `fadeInUp 0.4s ease ${i * 0.06}s both`,
                    position: 'relative',
                  }}
                >
                  {inCart && (
                    <div style={{
                      position: 'absolute', top: '12px', right: '12px',
                      background: '#C0152A', color: '#fff',
                      borderRadius: '50%', width: '24px', height: '24px',
                      fontSize: '0.75rem', fontWeight: '700',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {inCart.quantity}
                    </div>
                  )}

                  <div style={{ marginBottom: '0.75rem' }}>
                    <div style={{
                      display: 'inline-block',
                      background: available ? '#FFF0F2' : '#F5F5F5',
                      color: available ? '#C0152A' : '#999',
                      fontSize: '0.7rem',
                      fontWeight: '600',
                      letterSpacing: '0.08em',
                      padding: '3px 10px',
                      borderRadius: '20px',
                      marginBottom: '8px',
                    }}>
                      {available ? 'TERSEDIA' : 'HABIS'}
                    </div>
                    <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.1rem', fontWeight: '700', margin: '0 0 6px', color: '#1A0508' }}>
                      {menu.name}
                    </h3>
                    <p style={{ fontSize: '0.82rem', color: '#8B5A62', margin: 0, lineHeight: 1.5 }}>
                      {menu.description || 'Tidak ada deskripsi'}
                    </p>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', paddingTop: '0.75rem', borderTop: '1px solid #FFD6DB' }}>
                    <span style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.15rem', fontWeight: '700', color: '#C0152A' }}>
                      Rp {menu.price.toLocaleString("id-ID")}
                    </span>
                    <span style={{ fontSize: '0.78rem', color: '#8B5A62', background: '#FFF0F2', padding: '3px 10px', borderRadius: '20px' }}>
                      Stok: {menu.stock}
                    </span>
                  </div>

                  <button
                    onClick={() => addToCart(menu)}
                    disabled={!available}
                    style={{
                      width: '100%',
                      padding: '0.65rem',
                      borderRadius: '10px',
                      border: 'none',
                      background: available ? 'linear-gradient(135deg, #C0152A, #8B0D1E)' : '#E5E5E5',
                      color: available ? '#FFFFFF' : '#999',
                      fontFamily: "'DM Sans', sans-serif",
                      fontWeight: '600',
                      fontSize: '0.88rem',
                      cursor: available ? 'pointer' : 'not-allowed',
                      transition: 'all 0.2s ease',
                      letterSpacing: '0.02em',
                    }}
                    onMouseEnter={(e) => { if (available) e.target.style.transform = 'translateY(-1px)'; }}
                    onMouseLeave={(e) => { e.target.style.transform = 'translateY(0)'; }}
                  >
                    {available ? '+ Tambah ke Keranjang' : 'Stok Habis'}
                  </button>
                </div>
              );
            })}

            {menus.length === 0 && (
              <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: '3rem', color: '#8B5A62' }}>
                <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🍽️</div>
                <p>Memuat menu...</p>
              </div>
            )}
          </div>
        </div>

        {/* Cart Sidebar */}
        <div style={{
          background: '#FFFFFF',
          borderRadius: '20px',
          padding: '1.75rem',
          boxShadow: '0 8px 32px rgba(139,13,30,0.12)',
          position: 'sticky',
          top: '80px',
          border: '1px solid #FFD6DB',
        }}>
          {/* Cart Header */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.3rem', fontWeight: '700', color: '#8B0D1E', margin: 0 }}>
              🛒 Keranjang
            </h2>
            {cartCount > 0 && (
              <span style={{
                background: '#C0152A', color: '#fff',
                borderRadius: '20px', padding: '3px 12px',
                fontSize: '0.8rem', fontWeight: '700',
              }}>
                {cartCount} item
              </span>
            )}
          </div>

          {/* Customer Name */}
          <div style={{ marginBottom: '1.25rem' }}>
            <label style={{ display: 'block', fontSize: '0.78rem', fontWeight: '600', color: '#4A1520', marginBottom: '6px', letterSpacing: '0.05em' }}>
              NAMA PELANGGAN
            </label>
            <input
              type="text"
              placeholder="Masukkan nama Anda..."
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              style={{
                width: '100%',
                padding: '0.65rem 0.875rem',
                border: '2px solid #FFD6DB',
                borderRadius: '10px',
                fontFamily: "'DM Sans', sans-serif",
                fontSize: '0.9rem',
                outline: 'none',
                transition: 'border-color 0.2s',
                boxSizing: 'border-box',
              }}
              onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
              onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
            />
          </div>

          {/* Cart Items */}
          {cart.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '2rem 0', color: '#8B5A62' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🛒</div>
              <p style={{ fontSize: '0.88rem', margin: 0 }}>Belum ada pesanan.</p>
            </div>
          ) : (
            <>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', marginBottom: '1.25rem' }}>
                {cart.map((item) => (
                  <div key={item.menu_item_id} style={{
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '0.75rem', background: '#FFF0F2', borderRadius: '10px',
                  }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.88rem', fontWeight: '600', color: '#1A0508' }}>{item.name}</div>
                      <div style={{ fontSize: '0.78rem', color: '#8B5A62' }}>
                        Rp {item.price.toLocaleString("id-ID")} × {item.quantity}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <button
                        onClick={() => removeFromCart(item.menu_item_id)}
                        style={{ width: '24px', height: '24px', borderRadius: '50%', border: '1px solid #FFD6DB', background: '#fff', cursor: 'pointer', fontSize: '0.9rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#C0152A', fontWeight: 'bold' }}
                      >−</button>
                      <span style={{ fontWeight: '700', color: '#C0152A', minWidth: '20px', textAlign: 'center' }}>{item.quantity}</span>
                      <button
                        onClick={() => addToCart({ id: item.menu_item_id, name: item.name, price: item.price })}
                        style={{ width: '24px', height: '24px', borderRadius: '50%', border: 'none', background: '#C0152A', cursor: 'pointer', fontSize: '0.9rem', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold' }}
                      >+</button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total */}
              <div style={{
                borderTop: '2px dashed #FFD6DB',
                paddingTop: '1rem',
                marginBottom: '1.25rem',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <span style={{ fontWeight: '600', color: '#4A1520' }}>Total</span>
                <span style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.25rem', fontWeight: '700', color: '#C0152A' }}>
                  Rp {total.toLocaleString("id-ID")}
                </span>
              </div>

              <button
                onClick={checkout}
                style={{
                  width: '100%',
                  padding: '0.875rem',
                  borderRadius: '12px',
                  border: 'none',
                  background: 'linear-gradient(135deg, #D4A017, #F5C842)',
                  color: '#5C0812',
                  fontFamily: "'DM Sans', sans-serif",
                  fontWeight: '700',
                  fontSize: '1rem',
                  cursor: 'pointer',
                  letterSpacing: '0.03em',
                  boxShadow: '0 4px 15px rgba(212,160,23,0.4)',
                  transition: 'all 0.2s ease',
                }}
                onMouseEnter={(e) => { e.target.style.transform = 'translateY(-2px)'; e.target.style.boxShadow = '0 8px 25px rgba(212,160,23,0.5)'; }}
                onMouseLeave={(e) => { e.target.style.transform = 'translateY(0)'; e.target.style.boxShadow = '0 4px 15px rgba(212,160,23,0.4)'; }}
              >
                ✓ Checkout Sekarang
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
