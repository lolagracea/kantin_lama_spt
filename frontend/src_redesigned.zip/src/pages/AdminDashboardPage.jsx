import { useEffect, useState } from "react";
import api from "../api/api";

const STATUS_CONFIG = {
  waiting:    { label: 'Menunggu',   bg: '#FFF3CD', color: '#856404', icon: '⏳' },
  processing: { label: 'Diproses',   bg: '#FFF0F2', color: '#C0152A', icon: '👨‍🍳' },
  ready:      { label: 'Siap',       bg: '#D4EDDA', color: '#155724', icon: '✅' },
  completed:  { label: 'Selesai',    bg: '#D1ECF1', color: '#0C5460', icon: '🎉' },
  cancelled:  { label: 'Dibatalkan', bg: '#F8D7DA', color: '#721C24', icon: '❌' },
};

export default function AdminDashboardPage() {
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const res = await api.get("/orders/");
    setOrders(res.data);
  };

  useEffect(() => { fetchOrders(); }, []);

  const updateStatus = async (orderId, status) => {
    await api.patch(`/orders/${orderId}/status`, { status });
    fetchOrders();
  };

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '2rem 1.5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
          <div style={{ width: '4px', height: '28px', background: 'linear-gradient(180deg, #C0152A, #8B0D1E)', borderRadius: '2px' }} />
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: '900', color: '#8B0D1E', margin: 0 }}>
            Dashboard Pesanan
          </h1>
        </div>
        <p style={{ color: '#8B5A62', marginLeft: '14px', fontSize: '0.9rem' }}>
          Kelola dan perbarui status pesanan pelanggan
        </p>
      </div>

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        {Object.entries(STATUS_CONFIG).map(([key, cfg]) => {
          const count = orders.filter(o => o.status === key).length;
          return (
            <div key={key} style={{
              background: '#fff', borderRadius: '14px', padding: '1rem 1.25rem',
              boxShadow: '0 2px 12px rgba(139,13,30,0.07)',
              borderLeft: `4px solid ${cfg.color}`,
              display: 'flex', flexDirection: 'column', gap: '4px',
            }}>
              <span style={{ fontSize: '1.5rem' }}>{cfg.icon}</span>
              <span style={{ fontSize: '1.5rem', fontWeight: '700', color: cfg.color }}>{count}</span>
              <span style={{ fontSize: '0.75rem', color: '#8B5A62', fontWeight: '500' }}>{cfg.label}</span>
            </div>
          );
        })}
      </div>

      {/* Orders list */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {orders.map((order, i) => {
          const cfg = STATUS_CONFIG[order.status] || STATUS_CONFIG.waiting;
          return (
            <div key={order.id} style={{
              background: '#FFFFFF',
              borderRadius: '16px',
              padding: '1.5rem',
              boxShadow: '0 4px 20px rgba(139,13,30,0.08)',
              border: '1px solid #FFE8EC',
              animation: `fadeInUp 0.4s ease ${i * 0.05}s both`,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              flexWrap: 'wrap',
              gap: '1rem',
            }}>
              {/* Order Info */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem', flex: 1 }}>
                <div style={{
                  width: '56px', height: '56px',
                  background: 'linear-gradient(135deg, #C0152A, #8B0D1E)',
                  borderRadius: '14px',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: '#fff',
                  fontFamily: "'Playfair Display', serif",
                  fontWeight: '900', fontSize: '0.9rem',
                  flexShrink: 0,
                }}>
                  #{order.queue_number}
                </div>
                <div>
                  <div style={{ fontWeight: '700', fontSize: '1rem', color: '#1A0508', marginBottom: '2px' }}>
                    {order.customer_name}
                  </div>
                  <div style={{ fontSize: '0.85rem', color: '#8B5A62' }}>
                    Total: <strong style={{ color: '#C0152A' }}>Rp {order.total_price.toLocaleString("id-ID")}</strong>
                  </div>
                  <span style={{
                    display: 'inline-flex', alignItems: 'center', gap: '4px',
                    marginTop: '6px', padding: '3px 10px',
                    borderRadius: '20px',
                    background: cfg.bg, color: cfg.color,
                    fontSize: '0.75rem', fontWeight: '600',
                  }}>
                    {cfg.icon} {cfg.label}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {[
                  { status: 'processing', label: '👨‍🍳 Proses', bg: '#FF8C00', hover: '#E07D00' },
                  { status: 'ready',      label: '✅ Siap',   bg: '#28A745', hover: '#218838' },
                  { status: 'completed',  label: '🎉 Selesai', bg: '#007BFF', hover: '#0056b3' },
                  { status: 'cancelled',  label: '❌ Batal',  bg: '#C0152A', hover: '#8B0D1E' },
                ].map((btn) => (
                  <button
                    key={btn.status}
                    onClick={() => updateStatus(order.id, btn.status)}
                    style={{
                      padding: '0.45rem 0.9rem',
                      borderRadius: '8px',
                      border: 'none',
                      background: btn.bg,
                      color: '#FFFFFF',
                      fontFamily: "'DM Sans', sans-serif",
                      fontWeight: '600',
                      fontSize: '0.8rem',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                    }}
                    onMouseEnter={(e) => { e.target.style.background = btn.hover; e.target.style.transform = 'translateY(-1px)'; }}
                    onMouseLeave={(e) => { e.target.style.background = btn.bg; e.target.style.transform = 'translateY(0)'; }}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
            </div>
          );
        })}

        {orders.length === 0 && (
          <div style={{
            background: '#FFFFFF', borderRadius: '16px', padding: '4rem',
            textAlign: 'center', color: '#8B5A62',
            boxShadow: '0 4px 20px rgba(139,13,30,0.06)',
          }}>
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📋</div>
            <p style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.1rem' }}>Belum ada pesanan.</p>
          </div>
        )}
      </div>
    </div>
  );
}
