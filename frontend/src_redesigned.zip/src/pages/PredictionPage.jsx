import { useState } from "react";
import api from "../api/api";

const DAY_NAMES = ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];

export default function PredictionPage() {
  const [form, setForm] = useState({ day_of_week: 1, hour: 12, menu_id: 1, stock_start: 50 });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const predict = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    try {
      const res = await api.post("/predictions/demand", {
        day_of_week: Number(form.day_of_week),
        hour: Number(form.hour),
        menu_id: Number(form.menu_id),
        stock_start: Number(form.stock_start),
      });
      setResult(res.data.result);
    } catch (error) {
      alert(error.response?.data?.detail || "Prediksi gagal");
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = {
    width: '100%',
    padding: '0.75rem 1rem',
    border: '2px solid #FFD6DB',
    borderRadius: '10px',
    fontFamily: "'DM Sans', sans-serif",
    fontSize: '0.95rem',
    outline: 'none',
    background: '#fff',
    boxSizing: 'border-box',
    color: '#1A0508',
    transition: 'border-color 0.2s',
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem 1.5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
          <div style={{ width: '4px', height: '28px', background: 'linear-gradient(180deg, #C0152A, #8B0D1E)', borderRadius: '2px' }} />
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: '900', color: '#8B0D1E', margin: 0 }}>
            Prediksi Permintaan
          </h1>
        </div>
        <p style={{ color: '#8B5A62', marginLeft: '14px', fontSize: '0.9rem' }}>
          GPU-Based Demand Prediction — Estimasi kebutuhan stok menu
        </p>
      </div>

      {/* Form Card */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        padding: '2rem',
        marginBottom: '2rem',
        boxShadow: '0 8px 32px rgba(139,13,30,0.1)',
        border: '1px solid #FFE8EC',
      }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: '12px',
          marginBottom: '1.75rem', paddingBottom: '1.25rem',
          borderBottom: '1px solid #FFE8EC',
        }}>
          <div style={{
            width: '44px', height: '44px',
            background: 'linear-gradient(135deg, #C0152A, #8B0D1E)',
            borderRadius: '12px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1.25rem',
          }}>
            📊
          </div>
          <div>
            <div style={{ fontWeight: '700', color: '#1A0508', fontSize: '1rem' }}>Parameter Prediksi</div>
            <div style={{ fontSize: '0.8rem', color: '#8B5A62' }}>Isi data di bawah untuk mendapatkan estimasi</div>
          </div>
        </div>

        <form onSubmit={predict}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '700', color: '#4A1520', marginBottom: '6px', letterSpacing: '0.08em' }}>
                HARI (1–7)
              </label>
              <select
                value={form.day_of_week}
                onChange={(e) => setForm({ ...form, day_of_week: e.target.value })}
                style={{ ...inputStyle, cursor: 'pointer' }}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
              >
                {[1,2,3,4,5,6,7].map(d => (
                  <option key={d} value={d}>{d} — {DAY_NAMES[d]}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '700', color: '#4A1520', marginBottom: '6px', letterSpacing: '0.08em' }}>
                JAM (0–23)
              </label>
              <input
                type="number"
                min={0} max={23}
                placeholder="12"
                value={form.hour}
                onChange={(e) => setForm({ ...form, hour: e.target.value })}
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '700', color: '#4A1520', marginBottom: '6px', letterSpacing: '0.08em' }}>
                MENU ID
              </label>
              <input
                type="number"
                min={1}
                placeholder="1"
                value={form.menu_id}
                onChange={(e) => setForm({ ...form, menu_id: e.target.value })}
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '700', color: '#4A1520', marginBottom: '6px', letterSpacing: '0.08em' }}>
                STOK AWAL
              </label>
              <input
                type="number"
                min={0}
                placeholder="50"
                value={form.stock_start}
                onChange={(e) => setForm({ ...form, stock_start: e.target.value })}
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '0.9rem',
              borderRadius: '12px',
              border: 'none',
              background: loading ? '#E5E5E5' : 'linear-gradient(135deg, #C0152A 0%, #8B0D1E 100%)',
              color: '#FFFFFF',
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: '700',
              fontSize: '1rem',
              cursor: loading ? 'not-allowed' : 'pointer',
              letterSpacing: '0.03em',
              boxShadow: loading ? 'none' : '0 6px 20px rgba(192,21,42,0.35)',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => { if (!loading) { e.target.style.transform = 'translateY(-2px)'; e.target.style.boxShadow = '0 10px 30px rgba(192,21,42,0.4)'; }}}
            onMouseLeave={(e) => { e.target.style.transform = 'translateY(0)'; e.target.style.boxShadow = loading ? 'none' : '0 6px 20px rgba(192,21,42,0.35)'; }}
          >
            {loading ? '⏳ Memproses...' : '🔮 Prediksi Demand'}
          </button>
        </form>
      </div>

      {/* Result */}
      {result && (
        <div style={{
          background: '#FFFFFF',
          borderRadius: '20px',
          padding: '2rem',
          boxShadow: '0 8px 32px rgba(139,13,30,0.1)',
          border: '1px solid #FFE8EC',
          animation: 'fadeInUp 0.5s ease both',
        }}>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.4rem', fontWeight: '700', color: '#8B0D1E', marginBottom: '1.5rem' }}>
            📊 Hasil Prediksi
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
            <div style={{
              background: 'linear-gradient(135deg, #FFF0F2, #FFE8EC)',
              borderRadius: '16px',
              padding: '1.5rem',
              borderLeft: '4px solid #C0152A',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#8B5A62', letterSpacing: '0.1em', marginBottom: '0.75rem' }}>
                PREDIKSI PERMINTAAN
              </div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '3rem', fontWeight: '900', color: '#C0152A', lineHeight: 1 }}>
                {result.predicted_demand}
              </div>
              <div style={{ color: '#8B5A62', fontSize: '0.85rem', marginTop: '4px' }}>porsi</div>
            </div>

            <div style={{
              background: 'linear-gradient(135deg, #F0FFF4, #E8F5E9)',
              borderRadius: '16px',
              padding: '1.5rem',
              borderLeft: '4px solid #28A745',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: '0.75rem', fontWeight: '700', color: '#4A7C59', letterSpacing: '0.1em', marginBottom: '0.75rem' }}>
                REKOMENDASI STOK
              </div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: '3rem', fontWeight: '900', color: '#28A745', lineHeight: 1 }}>
                {result.recommended_stock}
              </div>
              <div style={{ color: '#4A7C59', fontSize: '0.85rem', marginTop: '4px' }}>porsi</div>
            </div>
          </div>

          <div style={{
            marginTop: '1.25rem',
            padding: '1rem 1.25rem',
            background: '#FFFBF0',
            borderRadius: '10px',
            border: '1px solid #F5C842',
            display: 'flex', alignItems: 'center', gap: '10px',
            fontSize: '0.85rem', color: '#856404',
          }}>
            <span style={{ fontSize: '1.1rem' }}>💡</span>
            <span>Prediksi dihasilkan berdasarkan model GPU. Gunakan sebagai panduan stok, bukan keputusan mutlak.</span>
          </div>
        </div>
      )}
    </div>
  );
}
