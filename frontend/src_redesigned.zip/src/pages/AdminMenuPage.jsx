import { useEffect, useState } from "react";
import api from "../api/api";

export default function AdminMenuPage() {
  const [menus, setMenus] = useState([]);
  const [form, setForm] = useState({ name: "", description: "", price: "", stock: "" });
  const [submitting, setSubmitting] = useState(false);

  const fetchMenus = async () => {
    const res = await api.get("/menus/");
    setMenus(res.data);
  };

  useEffect(() => { fetchMenus(); }, []);

  const createMenu = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post("/menus/", {
        name: form.name,
        description: form.description,
        price: Number(form.price),
        stock: Number(form.stock),
      });
      setForm({ name: "", description: "", price: "", stock: "" });
      fetchMenus();
    } finally {
      setSubmitting(false);
    }
  };

  const deleteMenu = async (id) => {
    if (!confirm("Yakin hapus menu ini?")) return;
    await api.delete(`/menus/${id}`);
    fetchMenus();
  };

  const inputStyle = {
    width: '100%',
    padding: '0.65rem 0.875rem',
    border: '2px solid #FFD6DB',
    borderRadius: '10px',
    fontFamily: "'DM Sans', sans-serif",
    fontSize: '0.9rem',
    outline: 'none',
    background: '#fff',
    boxSizing: 'border-box',
    transition: 'border-color 0.2s',
  };

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', padding: '2rem 1.5rem' }}>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
          <div style={{ width: '4px', height: '28px', background: 'linear-gradient(180deg, #C0152A, #8B0D1E)', borderRadius: '2px' }} />
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.8rem', fontWeight: '900', color: '#8B0D1E', margin: 0 }}>
            Kelola Menu Kantin
          </h1>
        </div>
        <p style={{ color: '#8B5A62', marginLeft: '14px', fontSize: '0.9rem' }}>
          Tambah, lihat, dan hapus item menu
        </p>
      </div>

      {/* Add Menu Form */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        padding: '1.75rem',
        marginBottom: '2rem',
        boxShadow: '0 6px 24px rgba(139,13,30,0.1)',
        border: '1px solid #FFE8EC',
      }}>
        <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: '1.2rem', fontWeight: '700', color: '#8B0D1E', margin: '0 0 1.25rem' }}>
          ✏️ Tambah Menu Baru
        </h2>

        <form onSubmit={createMenu}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '600', color: '#4A1520', marginBottom: '5px', letterSpacing: '0.05em' }}>NAMA MENU *</label>
              <input
                style={inputStyle}
                placeholder="Contoh: Nasi Goreng"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
                required
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '600', color: '#4A1520', marginBottom: '5px', letterSpacing: '0.05em' }}>DESKRIPSI</label>
              <input
                style={inputStyle}
                placeholder="Deskripsi singkat..."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '600', color: '#4A1520', marginBottom: '5px', letterSpacing: '0.05em' }}>HARGA (Rp) *</label>
              <input
                style={inputStyle}
                type="number"
                placeholder="15000"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
                required
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.75rem', fontWeight: '600', color: '#4A1520', marginBottom: '5px', letterSpacing: '0.05em' }}>STOK *</label>
              <input
                style={inputStyle}
                type="number"
                placeholder="50"
                value={form.stock}
                onChange={(e) => setForm({ ...form, stock: e.target.value })}
                onFocus={(e) => { e.target.style.borderColor = '#C0152A'; }}
                onBlur={(e) => { e.target.style.borderColor = '#FFD6DB'; }}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            style={{
              padding: '0.75rem 2rem',
              borderRadius: '10px',
              border: 'none',
              background: submitting ? '#E5E5E5' : 'linear-gradient(135deg, #C0152A, #8B0D1E)',
              color: '#FFFFFF',
              fontFamily: "'DM Sans', sans-serif",
              fontWeight: '700',
              fontSize: '0.95rem',
              cursor: submitting ? 'not-allowed' : 'pointer',
              boxShadow: '0 4px 15px rgba(192,21,42,0.3)',
              transition: 'all 0.2s ease',
            }}
            onMouseEnter={(e) => { if (!submitting) e.target.style.transform = 'translateY(-1px)'; }}
            onMouseLeave={(e) => { e.target.style.transform = 'translateY(0)'; }}
          >
            {submitting ? 'Menyimpan...' : '+ Tambah Menu'}
          </button>
        </form>
      </div>

      {/* Menu Table */}
      <div style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        boxShadow: '0 6px 24px rgba(139,13,30,0.08)',
        border: '1px solid #FFE8EC',
        overflow: 'hidden',
      }}>
        {/* Table header */}
        <div style={{
          background: 'linear-gradient(135deg, #8B0D1E, #C0152A)',
          padding: '1rem 1.5rem',
          display: 'grid',
          gridTemplateColumns: '2fr 1fr 1fr 80px',
          gap: '1rem',
        }}>
          {['Menu', 'Harga', 'Stok', 'Aksi'].map((h) => (
            <div key={h} style={{ color: 'rgba(255,255,255,0.9)', fontSize: '0.75rem', fontWeight: '700', letterSpacing: '0.1em' }}>
              {h.toUpperCase()}
            </div>
          ))}
        </div>

        {/* Table rows */}
        {menus.map((menu, i) => (
          <div key={menu.id} style={{
            padding: '1rem 1.5rem',
            display: 'grid',
            gridTemplateColumns: '2fr 1fr 1fr 80px',
            gap: '1rem',
            alignItems: 'center',
            borderBottom: '1px solid #FFF0F2',
            background: i % 2 === 0 ? '#FFFFFF' : '#FFFAFB',
            transition: 'background 0.15s',
          }}
            onMouseEnter={(e) => { e.currentTarget.style.background = '#FFF0F2'; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = i % 2 === 0 ? '#FFFFFF' : '#FFFAFB'; }}
          >
            <div>
              <div style={{ fontWeight: '600', color: '#1A0508', fontSize: '0.92rem' }}>{menu.name}</div>
              {menu.description && <div style={{ fontSize: '0.78rem', color: '#8B5A62', marginTop: '2px' }}>{menu.description}</div>}
            </div>
            <div style={{ fontFamily: "'Playfair Display', serif", fontWeight: '700', color: '#C0152A', fontSize: '0.95rem' }}>
              Rp {menu.price.toLocaleString("id-ID")}
            </div>
            <div>
              <span style={{
                display: 'inline-block',
                padding: '3px 12px',
                borderRadius: '20px',
                background: menu.stock > 0 ? '#D4EDDA' : '#F8D7DA',
                color: menu.stock > 0 ? '#155724' : '#721C24',
                fontSize: '0.8rem', fontWeight: '600',
              }}>
                {menu.stock}
              </span>
            </div>
            <div>
              <button
                onClick={() => deleteMenu(menu.id)}
                style={{
                  padding: '0.35rem 0.75rem',
                  borderRadius: '8px',
                  border: '1px solid #FFD6DB',
                  background: '#fff',
                  color: '#C0152A',
                  fontFamily: "'DM Sans', sans-serif",
                  fontWeight: '600',
                  fontSize: '0.8rem',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                }}
                onMouseEnter={(e) => { e.target.style.background = '#C0152A'; e.target.style.color = '#fff'; e.target.style.border = '1px solid #C0152A'; }}
                onMouseLeave={(e) => { e.target.style.background = '#fff'; e.target.style.color = '#C0152A'; e.target.style.border = '1px solid #FFD6DB'; }}
              >
                Hapus
              </button>
            </div>
          </div>
        ))}

        {menus.length === 0 && (
          <div style={{ padding: '3rem', textAlign: 'center', color: '#8B5A62' }}>
            <div style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>🍽️</div>
            <p>Belum ada menu. Tambahkan menu pertama Anda!</p>
          </div>
        )}
      </div>
    </div>
  );
}
