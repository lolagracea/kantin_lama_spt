import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import MenuPage from "./pages/MenuPage";
import AdminDashboardPage from "./pages/AdminDashboardPage";
import AdminMenuPage from "./pages/AdminMenuPage";
import PredictionPage from "./pages/PredictionPage";

function NavLink({ to, children }) {
  const location = useLocation();
  const isActive = location.pathname === to;
  return (
    <Link
      to={to}
      style={{
        color: isActive ? '#D4A017' : 'rgba(255,255,255,0.85)',
        fontWeight: isActive ? '600' : '400',
        textDecoration: 'none',
        fontSize: '0.9rem',
        letterSpacing: '0.02em',
        padding: '6px 0',
        borderBottom: isActive ? '2px solid #D4A017' : '2px solid transparent',
        transition: 'all 0.2s ease',
      }}
    >
      {children}
    </Link>
  );
}

function Layout() {
  return (
    <div style={{ minHeight: '100svh', display: 'flex', flexDirection: 'column' }}>
      {/* Top accent bar */}
      <div style={{ height: '4px', background: 'linear-gradient(90deg, #D4A017, #C0152A, #8B0D1E)' }} />

      {/* Navbar */}
      <nav style={{
        background: 'linear-gradient(135deg, #8B0D1E 0%, #C0152A 60%, #A01020 100%)',
        padding: '0 2rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 4px 20px rgba(139, 13, 30, 0.5)',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        minHeight: '64px',
      }}>
        {/* Logo area */}
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '38px', height: '38px',
            background: 'linear-gradient(135deg, #D4A017, #F5C842)',
            borderRadius: '10px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '18px', fontWeight: 'bold',
            boxShadow: '0 2px 8px rgba(212,160,23,0.4)',
          }}>
            🍽
          </div>
          <div>
            <div style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: '1.15rem',
              fontWeight: '900',
              color: '#FFFFFF',
              lineHeight: 1.1,
              letterSpacing: '-0.01em',
            }}>Kantin Lama</div>
            <div style={{ fontSize: '0.7rem', color: 'rgba(212,160,23,0.9)', letterSpacing: '0.12em', fontWeight: '500' }}>
              IT DEL
            </div>
          </div>
        </Link>

        {/* Nav links */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
          <NavLink to="/">Menu</NavLink>
          <NavLink to="/admin/orders">Pesanan</NavLink>
          <NavLink to="/admin/menus">Kelola Menu</NavLink>
          <NavLink to="/admin/prediction">Prediksi</NavLink>
        </div>
      </nav>

      {/* Page content */}
      <main style={{ flex: 1, background: '#FDF8F0' }}>
        <Routes>
          <Route path="/" element={<MenuPage />} />
          <Route path="/admin/orders" element={<AdminDashboardPage />} />
          <Route path="/admin/menus" element={<AdminMenuPage />} />
          <Route path="/admin/prediction" element={<PredictionPage />} />
        </Routes>
      </main>

      {/* Footer */}
      <footer style={{
        background: 'linear-gradient(135deg, #5C0812 0%, #8B0D1E 100%)',
        color: 'rgba(255,255,255,0.6)',
        textAlign: 'center',
        padding: '1.25rem',
        fontSize: '0.8rem',
        letterSpacing: '0.05em',
      }}>
        © 2025 Kantin Lama IT Del &nbsp;·&nbsp; Sistem Pemesanan Cerdas
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout />
    </BrowserRouter>
  );
}
